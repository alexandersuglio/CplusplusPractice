#include <iostream>

#include "header.h"

int main() {
  
 Dogs dog1(34);
 
std::cout << dog1.getAge();

std::cout << dog1.name();

  
  
}