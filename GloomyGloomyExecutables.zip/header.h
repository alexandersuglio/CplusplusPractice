#include <iostream>

class Dogs
{
  public:
  Dogs();
  Dogs(int);
  //char setName(char);
  //void setName(char);
 // char getName();
 const char* name();
  void setAge(int);
  int getAge();
  
  private:
  //const char* name;
  int age;
  
};