#include <iostream>

#include "header.h"


Dogs::Dogs() : age(16)
{
  
}

Dogs::Dogs(int a) : age(a)
{
  
}

void Dogs::setAge(int a) 
{
  int age = a;

}

int Dogs::getAge()
{
  return age;
}


const char * Dogs::name()
{
  return "joker";
  
}
/*
Dogs::Dogs(): name("ruby")
{
  
}
*/

/*
void Dogs::setName(char derg)
{
  char dog = derg;
}

char Dogs::getName()
{

return dog;
}
*/


/*
class Dogs
{
  public:
  Dogs();
  
  private:
  char name;
  
};
*/