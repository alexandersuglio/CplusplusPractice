#include <iostream>

using namespace std;

//function template example
template <class a, class b>
b showem(a c, b d)
{
   cout << d << " " << c;
}

//class template example
template <class J>
class Joker
{
  J first, second;
  
  public:
  Joker(J f, J s): first(f), second(s)
  {
  }
  J bigger();
};

template <class J>
J Joker<J>::bigger()
{
  return (first>second?first:second);
}



int main() 
{
  double x=6.3;
  int y=8;
  
  showem(x, y);
  cout << endl;
  
  
  char j = 'o';
  string k = "joker dog";
  
  showem(j, k);
  cout << endl;
  
  showem(x, j);
  
  cout << endl;
  cout << endl;
  cout << endl;
  
  Joker <int> obj1(45, 43);
  
  cout << obj1.bigger();

  
  
}